from django.shortcuts import render, redirect
from .models import Member
from .forms import Memberform
from django.contrib import messages


def home(request):
    member_data = Member.objects.all
    return render(request, 'home.html', {'all': member_data})


def join(request):
    if request.method == "POST":
        form = Memberform(request.POST or None)
        if form.is_valid():
            form.save()
        else:
            messages.success(request, 'THERE WAS AN ERROR! TRY AGAIN!')
            return redirect('join')

        messages.success(request, 'New User Has Been add to database')
        return redirect('home')

    else:
        return render(request, 'home.html', {})

